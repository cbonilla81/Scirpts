# ProxSec v0.1

ProxSec is a read-only Proxmox VE security assessment utility with a FastAPI web UI.

## Current checks

- Cluster/node inventory
- Root account visibility and broad Administrator ACLs
- Node and datacenter firewall status
- VM/LXC firewall status (when the token can read it)
- Privileged LXC detection
- LXC nesting detection
- Basic bridge/network review
- Network storage review
- Cluster node availability
- Risk score and severity counts
- JSON and CSV exports

ProxSec intentionally treats inaccessible endpoints as **skipped**, not secure. Some API fields differ between Proxmox releases, so controls only fail when the relevant configuration is observable.

## Requirements

- Python 3.12+ or Docker
- Network connectivity to Proxmox TCP/8006
- A Proxmox API token with read/audit permissions for the resources you want assessed

Use a dedicated low-privilege token. Do not use an unrestricted root token in production.

## Run on Windows

```powershell
cd proxsec
.\run.ps1
```

Open `http://localhost:8080`.

## Run on Linux

```bash
cd proxsec
chmod +x run.sh
./run.sh
```

## Run with Docker

```bash
docker compose up --build
```

Open `http://localhost:8080`.

## Proxmox API token

Create a dedicated service user/token in Proxmox and assign only the audit/read privileges required for the desired scope. In the UI, enter the complete token identity, for example:

`proxsec@pve!scanner`

The Authorization header format used by the application is:

`PVEAPIToken=<token-id>=<token-secret>`

The token secret is not written to disk by this version of ProxSec.

## TLS

Keep **Verify TLS certificate** enabled for production. If your lab uses the default self-signed certificate, you can temporarily disable validation, but replacing it with a trusted certificate is preferred.

## Security boundaries

v0.1 performs HTTP GET operations only. It does not run remediation commands and does not change Proxmox configuration. Run the application on a trusted administrative system and protect access to the ProxSec UI because scan reports contain sensitive infrastructure information.

## Next planned controls

- SSH host-hardening module
- apt/repository/security update assessment
- TLS protocol and certificate checks
- backup-job/retention assessment
- Corosync/migration/storage segmentation checks
- MFA/TFA checks with release-aware parsing
- YAML rule packs and NIST/CIS mappings
- PDF executive report and scan history
