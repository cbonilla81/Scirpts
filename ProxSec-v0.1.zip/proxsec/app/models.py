from dataclasses import dataclass, asdict

@dataclass
class Finding:
    id: str
    title: str
    severity: str
    category: str
    status: str
    recommendation: str
    evidence: str = ''
    asset: str = 'cluster'

    def dict(self):
        return asdict(self)
