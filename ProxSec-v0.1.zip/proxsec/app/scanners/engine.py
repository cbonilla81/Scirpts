from collections import Counter
from datetime import datetime, timezone
from app.models import Finding

WEIGHTS = {'critical': 20, 'high': 12, 'medium': 6, 'low': 2, 'info': 0}

class AssessmentEngine:
    def __init__(self, client):
        self.p = client
        self.findings = []
        self.skipped = []

    def add(self, *args, **kwargs):
        self.findings.append(Finding(*args, **kwargs))

    def safe(self, path):
        data = self.p.get(path, optional=True)
        if data is None:
            self.skipped.append(path)
        return data

    def run(self):
        version = self.p.get('/version') or {}
        nodes = self.p.get('/nodes') or []
        resources = self.safe('/cluster/resources') or []
        users = self.safe('/access/users') or []
        acls = self.safe('/access/acl') or []
        storages = self.safe('/storage') or []

        self.check_identity(users, acls)
        self.check_nodes(nodes)
        self.check_guest_security(resources)
        self.check_storage(storages)
        self.check_cluster_firewall()

        score = max(0, 100 - sum(WEIGHTS.get(f.severity, 0) for f in self.findings if f.status == 'FAIL'))
        counts = Counter(f.severity for f in self.findings if f.status == 'FAIL')
        inventory = {
            'nodes': len(nodes),
            'vms': sum(1 for r in resources if r.get('type') == 'qemu'),
            'containers': sum(1 for r in resources if r.get('type') == 'lxc'),
            'storage': len(storages),
        }
        return {
            'generated_at': datetime.now(timezone.utc).isoformat(),
            'product': 'ProxSec',
            'version': '0.1.0',
            'proxmox_version': version.get('version', 'unknown'),
            'release': version.get('release', ''),
            'score': score,
            'risk': self.risk_label(score),
            'counts': {k: counts.get(k, 0) for k in ['critical','high','medium','low','info']},
            'inventory': inventory,
            'findings': [f.dict() for f in sorted(self.findings, key=lambda x: list(WEIGHTS).index(x.severity))],
            'skipped_endpoints': sorted(set(self.skipped)),
        }

    @staticmethod
    def risk_label(score):
        if score >= 90: return 'LOW'
        if score >= 75: return 'MODERATE'
        if score >= 50: return 'HIGH'
        return 'CRITICAL'

    def check_identity(self, users, acls):
        root = next((u for u in users if u.get('userid') == 'root@pam'), None)
        if root and root.get('enable', 1):
            self.add('PVE-IAM-001','Built-in root@pam account is enabled','medium','Identity','FAIL',
                     'Limit direct root usage; use named administrative accounts and MFA where operationally feasible.',
                     'root@pam returned as enabled by /access/users')
        admins = set()
        for a in acls:
            if str(a.get('roleid','')).lower() == 'administrator':
                subject = a.get('ugid') or a.get('userid') or 'unknown'
                admins.add(subject)
                if a.get('path') == '/':
                    self.add('PVE-IAM-002','Administrator role assigned at root scope','high','Identity','FAIL',
                             'Apply least privilege and scope administrator assignments to the minimum required path.',
                             f"Subject {subject} has Administrator on /", subject)
        for u in users:
            uid = u.get('userid','unknown')
            is_admin = uid in admins
            # PVE API fields differ across releases/realms. Only fail MFA when explicit absence is observable.
            if is_admin and ('totp-locked' in u or 'tfa' in u) and not u.get('tfa'):
                self.add('PVE-IAM-003','Privileged account has no observable TFA configuration','high','Identity','FAIL',
                         'Require two-factor authentication for privileged administrative identities.',
                         f"Privileged user {uid}; no TFA field/value observed", uid)
            if not u.get('enable', 1):
                self.add('PVE-IAM-004','Disabled account retained','info','Identity','REVIEW',
                         'Validate that disabled accounts are still required; remove obsolete identities.', uid, uid)

    def check_nodes(self, nodes):
        for n in nodes:
            node = n.get('node','unknown')
            status = n.get('status','unknown')
            if status != 'online':
                self.add('PVE-CLUSTER-001','Cluster node is not online','medium','Cluster','FAIL',
                         'Investigate node availability and cluster health.', f"status={status}", node)
            fw = self.safe(f'/nodes/{node}/firewall/options')
            if fw is not None and not int(fw.get('enable',0) or 0):
                self.add('PVE-FW-001','Node firewall is disabled','high','Firewall','FAIL',
                         'Enable and validate the Proxmox firewall on each node using an allow-listed management policy.',
                         'firewall enable=0', node)
            net = self.safe(f'/nodes/{node}/network') or []
            for iface in net:
                if iface.get('type') == 'bridge' and iface.get('address') and not iface.get('bridge_ports'):
                    self.add('PVE-NET-001','Bridge has host IP but no visible bridge ports','low','Network','REVIEW',
                             'Validate that management, storage, cluster and guest traffic are intentionally segmented.',
                             f"{iface.get('iface')} address={iface.get('address')}", node)

    def check_guest_security(self, resources):
        for r in resources:
            typ = r.get('type')
            if typ not in ('qemu','lxc'): continue
            node, vmid = r.get('node'), r.get('vmid')
            name = r.get('name') or f'{typ}-{vmid}'
            if typ == 'lxc':
                cfg = self.safe(f'/nodes/{node}/lxc/{vmid}/config')
                if cfg:
                    # unprivileged=1 is safer; absent/0 means privileged.
                    if not int(cfg.get('unprivileged',0) or 0):
                        self.add('PVE-LXC-001','Privileged LXC container detected','critical','Containers','FAIL',
                                 'Prefer unprivileged containers unless a documented workload requirement exists.',
                                 'unprivileged=0 or unset', name)
                    features = str(cfg.get('features',''))
                    if 'nesting=1' in features:
                        self.add('PVE-LXC-002','LXC nesting enabled','medium','Containers','FAIL',
                                 'Disable nesting when it is not explicitly required and document exceptions.', features, name)
            fw = self.safe(f'/nodes/{node}/{typ}/{vmid}/firewall/options')
            if fw is not None and not int(fw.get('enable',0) or 0):
                self.add('PVE-GUEST-001','Guest firewall is disabled','medium','Guest Security','FAIL',
                         'Enable the guest firewall where compatible and enforce workload-specific network policy.',
                         'firewall enable=0', name)

    def check_storage(self, storages):
        for s in storages:
            stype = s.get('type','')
            sid = s.get('storage','unknown')
            if stype in ('cifs','nfs'):
                self.add('PVE-STOR-001','Network-attached storage configured','low','Storage','REVIEW',
                         'Validate storage traffic segmentation, authentication, ACLs and backup immutability controls.',
                         f"storage={sid}, type={stype}", sid)

    def check_cluster_firewall(self):
        fw = self.safe('/cluster/firewall/options')
        if fw is not None and not int(fw.get('enable',0) or 0):
            self.add('PVE-FW-002','Datacenter firewall is disabled','critical','Firewall','FAIL',
                     'Enable the datacenter firewall after validating management allow rules and recovery access.',
                     'cluster firewall enable=0')
