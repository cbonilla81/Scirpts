from fastapi import FastAPI, Form, Request
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from io import StringIO
import csv

from app.proxmox.client import ProxmoxClient, ProxmoxAPIError
from app.scanners.engine import AssessmentEngine

app = FastAPI(title="ProxSec", version="0.1.0")
templates = Jinja2Templates(directory="app/templates")
app.mount("/static", StaticFiles(directory="app/static"), name="static")

LAST_REPORT = None

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request, "report": LAST_REPORT})

@app.get("/health")
def health():
    return {"status": "ok", "service": "ProxSec", "version": "0.1.0"}

@app.post("/scan", response_class=HTMLResponse)
def scan(
    request: Request,
    host: str = Form(...),
    token_id: str = Form(...),
    token_secret: str = Form(...),
    verify_tls: bool = Form(False),
):
    global LAST_REPORT
    try:
        client = ProxmoxClient(host, token_id, token_secret, verify_tls=verify_tls)
        report = AssessmentEngine(client).run()
        LAST_REPORT = report
        return templates.TemplateResponse("index.html", {"request": request, "report": report})
    except (ProxmoxAPIError, ValueError) as exc:
        return templates.TemplateResponse("index.html", {"request": request, "report": None, "error": str(exc)}, status_code=400)

@app.get("/api/report")
def api_report():
    if not LAST_REPORT:
        return JSONResponse({"error": "No scan has been run"}, status_code=404)
    return LAST_REPORT

@app.get("/export/csv")
def export_csv():
    if not LAST_REPORT:
        return JSONResponse({"error": "No scan has been run"}, status_code=404)
    buf = StringIO()
    writer = csv.writer(buf)
    writer.writerow(["Control ID", "Severity", "Category", "Title", "Asset", "Status", "Evidence", "Recommendation"])
    for f in LAST_REPORT["findings"]:
        writer.writerow([f["id"], f["severity"], f["category"], f["title"], f.get("asset", ""), f["status"], f.get("evidence", ""), f["recommendation"]])
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv", headers={"Content-Disposition":"attachment; filename=proxsec-findings.csv"})
