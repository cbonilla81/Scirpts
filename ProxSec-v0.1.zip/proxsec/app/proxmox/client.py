from urllib.parse import urlparse
import requests
import urllib3

class ProxmoxAPIError(RuntimeError):
    pass

class ProxmoxClient:
    def __init__(self, host: str, token_id: str, token_secret: str, verify_tls: bool = True, timeout: int = 15):
        host = host.strip().rstrip('/')
        if not host.startswith(('https://', 'http://')):
            host = 'https://' + host
        parsed = urlparse(host)
        if not parsed.hostname:
            raise ValueError('Invalid Proxmox host')
        if parsed.port is None:
            host = f"{host}:8006"
        self.base = f"{host}/api2/json"
        self.verify_tls = verify_tls
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"Authorization": f"PVEAPIToken={token_id}={token_secret}"})
        if not verify_tls:
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    def get(self, path: str, params=None, optional=False):
        url = self.base + '/' + path.lstrip('/')
        try:
            r = self.session.get(url, params=params, verify=self.verify_tls, timeout=self.timeout)
        except requests.RequestException as exc:
            raise ProxmoxAPIError(f"Unable to contact Proxmox API: {exc}") from exc
        if optional and r.status_code in (401, 403, 404):
            return None
        if not r.ok:
            raise ProxmoxAPIError(f"Proxmox API returned HTTP {r.status_code} for {path}: {r.text[:300]}")
        try:
            payload = r.json()
        except ValueError as exc:
            raise ProxmoxAPIError(f"Invalid JSON from Proxmox API at {path}") from exc
        return payload.get('data')
