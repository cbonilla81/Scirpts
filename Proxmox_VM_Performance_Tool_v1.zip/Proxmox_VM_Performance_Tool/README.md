
# Proxmox Windows 11 VM Performance Test

A PowerShell GUI utility intended for repeatable performance testing of Windows 11 virtual machines running on Proxmox VE.

## What it tests

- CPU stress and utilization
- Memory allocation and utilization
- Disk performance using Microsoft DiskSpd
- Optional network throughput using iperf3
- HTML and CSV report export

## Requirements

- Windows 11
- Windows PowerShell 5.1 or later
- Administrator privileges recommended
- DiskSpd for storage benchmarks
- iperf3 for optional network benchmarks

## Folder recommendations

Create:

    C:\Tools\DiskSpd\
    C:\Tools\iperf3\

Place:

    C:\Tools\DiskSpd\diskspd.exe
    C:\Tools\iperf3\iperf3.exe

The GUI defaults to those locations.

## Running the tool

1. Extract this package.
2. Open PowerShell as Administrator.
3. If script execution is restricted for the current session, run:

       Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

4. Launch:

       .\Proxmox-VM-Performance-Test.ps1

## Recommended baseline VM

For meaningful comparisons, keep the VM specification unchanged between tests.

Example baseline:

- 8 vCPU
- 16 GB RAM
- Windows 11
- VirtIO SCSI Single controller
- VirtIO network adapter
- Current VirtIO drivers
- Same Windows power plan
- Same Proxmox host or identical host hardware

## Suggested test workflow

Run one baseline before changing Proxmox configuration.

Then compare after changing one variable at a time, such as:

- CPU type: x86-64-v2-AES vs host
- NUMA enabled/disabled
- Memory ballooning enabled/disabled
- VirtIO driver version
- VirtIO SCSI vs SATA
- Disk cache mode
- IO thread enabled/disabled
- Ceph/RBD settings
- Local LVM-thin vs Ceph
- VM migration to another host

## DiskSpd profiles used

The utility runs these profiles when DiskSpd is available:

1. 4K Random Read
2. 4K Random 70/30 Read/Write
3. 64K Sequential Read
4. 64K Sequential Write

Each profile currently runs for 30 seconds using a 4 GB temporary file.

## Network testing

iperf3 requires a second system running an iperf3 server.

On the server:

    iperf3 -s

In the GUI, enter that server's IP address or resolvable hostname.

Example:

    10.10.20.50

Then enable "iperf3 Network".

## Reports

Click "EXPORT REPORT".

Reports are saved to:

    Desktop\PVE-VM-Performance-Reports

Two files are created:

- HTML performance report
- CSV metric export

## Important notes

This tool intentionally places substantial load on the VM.

Do not run it on a production VM while users or production applications are active.

Disk benchmarks generate temporary write activity and may significantly increase storage latency while running.

Memory stress is capped at approximately 55 percent of guest physical memory and additionally capped at 6 GB in this release to reduce the chance of destabilizing the desktop.

## Proxmox counters worth watching simultaneously

From the Proxmox VE GUI, monitor:

- CPU usage
- Host CPU pressure
- Guest memory usage
- Disk I/O
- Disk latency
- Network throughput
- Ceph latency and IOPS, if using RBD
- Host load average

For Ceph-backed Windows VMs, compare guest DiskSpd latency with Ceph OSD and pool latency during the same test window.

## Version

v1.0
