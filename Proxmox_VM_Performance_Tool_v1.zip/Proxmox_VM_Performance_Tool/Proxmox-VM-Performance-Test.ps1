﻿
#requires -version 5.1
<#
.SYNOPSIS
    Proxmox Windows VM Performance Test Utility

.DESCRIPTION
    GUI-based performance and stress testing tool for Windows 11 VMs.
    Tests CPU, memory, disk (DiskSpd), and optional network throughput (iperf3).
    Collects Windows performance counters and exports HTML/CSV reports.

.NOTES
    Run PowerShell as Administrator.
    DiskSpd and iperf3 are optional external tools.
#>

Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase

$script:Results = [ordered]@{}
$script:CounterSamples = New-Object System.Collections.Generic.List[object]
$script:StopRequested = $false

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-SystemInventory {
    $os = Get-CimInstance Win32_OperatingSystem
    $cs = Get-CimInstance Win32_ComputerSystem
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='C:'"
    [ordered]@{
        Hostname       = $env:COMPUTERNAME
        OS             = $os.Caption
        OSVersion      = $os.Version
        CPU            = $cpu.Name
        LogicalCPUs    = $cs.NumberOfLogicalProcessors
        MemoryGB       = [math]::Round($cs.TotalPhysicalMemory / 1GB, 2)
        SystemDriveGB  = [math]::Round($disk.Size / 1GB, 2)
        FreeDriveGB    = [math]::Round($disk.FreeSpace / 1GB, 2)
        Timestamp      = (Get-Date).ToString("s")
    }
}

function Add-Log {
    param([string]$Text)
    $stamp = (Get-Date).ToString("HH:mm:ss")
    $txtLog.AppendText("[$stamp] $Text`r`n")
    $txtLog.ScrollToEnd()
    [System.Windows.Forms.Application]::DoEvents() 2>$null
}

function Update-Status {
    param([string]$Text, [int]$Progress = -1)
    $lblStatus.Text = $Text
    if ($Progress -ge 0) { $progress.Value = $Progress }
}

function Get-DurationSeconds {
    switch ($cmbDuration.SelectedItem.Content) {
        "1 minute"   { 60 }
        "5 minutes"  { 300 }
        "10 minutes" { 600 }
        "15 minutes" { 900 }
        "30 minutes" { 1800 }
        default      { 300 }
    }
}

function Invoke-CPUStress {
    param([int]$Seconds)

    Add-Log "Starting CPU stress test for $Seconds seconds."
    $jobs = @()
    $threadCount = [Environment]::ProcessorCount

    $jobScript = {
        param($EndTime)
        $x = 0.12345
        while ((Get-Date) -lt $EndTime) {
            for ($i=0; $i -lt 250000; $i++) {
                $x = [math]::Sqrt(($x * 1.0000001) + 0.000001)
            }
        }
    }

    $end = (Get-Date).AddSeconds($Seconds)
    for ($i=0; $i -lt $threadCount; $i++) {
        $jobs += Start-Job -ScriptBlock $jobScript -ArgumentList $end
    }

    $cpuSamples = New-Object System.Collections.Generic.List[double]
    while ((Get-Date) -lt $end -and -not $script:StopRequested) {
        $cpu = (Get-Counter '\Processor(_Total)\% Processor Time').CounterSamples.CookedValue
        $cpuSamples.Add([double]$cpu)
        $lblCPU.Text = ("CPU: {0:N1}%" -f $cpu)
        Start-Sleep -Seconds 1
        [System.Windows.Forms.Application]::DoEvents() 2>$null
    }

    $jobs | Stop-Job -ErrorAction SilentlyContinue
    $jobs | Remove-Job -Force -ErrorAction SilentlyContinue

    if ($cpuSamples.Count -gt 0) {
        $avg = ($cpuSamples | Measure-Object -Average).Average
        $max = ($cpuSamples | Measure-Object -Maximum).Maximum
    } else {
        $avg = 0; $max = 0
    }

    $script:Results.CPU = [ordered]@{
        AveragePercent = [math]::Round($avg,2)
        MaximumPercent = [math]::Round($max,2)
        DurationSeconds = $Seconds
        Status = $(if ($avg -ge 80) {"PASS"} else {"CHECK"})
    }
    Add-Log ("CPU test complete. Avg {0:N1}%, Max {1:N1}%." -f $avg, $max)
}

function Invoke-MemoryStress {
    param([int]$Seconds)

    Add-Log "Starting memory stress test for $Seconds seconds."
    $cs = Get-CimInstance Win32_ComputerSystem
    $total = [double]$cs.TotalPhysicalMemory
    $targetBytes = [math]::Min([int64]($total * 0.55), [int64](6GB))
    $chunkSize = 64MB
    $chunks = New-Object System.Collections.Generic.List[byte[]]
    $allocated = 0L
    $peakUsedPct = 0.0
    $end = (Get-Date).AddSeconds($Seconds)

    try {
        while ($allocated -lt $targetBytes -and -not $script:StopRequested) {
            $size = [int][math]::Min($chunkSize, ($targetBytes - $allocated))
            $arr = New-Object byte[] $size
            for ($i=0; $i -lt $arr.Length; $i += 4096) { $arr[$i] = 1 }
            $chunks.Add($arr)
            $allocated += $size
        }

        while ((Get-Date) -lt $end -and -not $script:StopRequested) {
            $os = Get-CimInstance Win32_OperatingSystem
            $usedPct = (($total - ($os.FreePhysicalMemory * 1KB)) / $total) * 100
            if ($usedPct -gt $peakUsedPct) { $peakUsedPct = $usedPct }
            $lblMemory.Text = ("Memory: {0:N1}%" -f $usedPct)
            Start-Sleep -Seconds 1
            [System.Windows.Forms.Application]::DoEvents() 2>$null
        }
    }
    finally {
        $chunks.Clear()
        [GC]::Collect()
    }

    $script:Results.Memory = [ordered]@{
        AllocatedStressGB = [math]::Round($allocated / 1GB, 2)
        PeakUsedPercent   = [math]::Round($peakUsedPct, 2)
        DurationSeconds   = $Seconds
        Status            = "PASS"
    }
    Add-Log ("Memory test complete. Allocated {0:N2} GB, Peak usage {1:N1}%." -f ($allocated/1GB), $peakUsedPct)
}

function Invoke-DiskSpdTest {
    param([string]$DiskSpdPath)

    if (-not (Test-Path $DiskSpdPath)) {
        Add-Log "DiskSpd not found. Skipping disk benchmark."
        $script:Results.Disk = [ordered]@{ Status="SKIPPED"; Reason="DiskSpd executable not found" }
        return
    }

    $testFile = Join-Path $env:TEMP "pve_vm_diskspd_test.dat"
    $profiles = @(
        @{Name="4K Random Read"; Args="-c4G -d30 -r -w0 -b4K -t4 -o8 -L `"$testFile`""},
        @{Name="4K Random 70/30"; Args="-c4G -d30 -r -w30 -b4K -t4 -o8 -L `"$testFile`""},
        @{Name="64K Sequential Read"; Args="-c4G -d30 -si -w0 -b64K -t2 -o8 -L `"$testFile`""},
        @{Name="64K Sequential Write"; Args="-c4G -d30 -si -w100 -b64K -t2 -o8 -L `"$testFile`""}
    )

    $diskResults = @()
    foreach ($p in $profiles) {
        if ($script:StopRequested) { break }
        Add-Log "Running DiskSpd profile: $($p.Name)"
        $output = & $DiskSpdPath ($p.Args -split ' ') 2>&1 | Out-String

        $iops = $null
        $mbps = $null
        $lat = $null

        $iopsMatches = [regex]::Matches($output, '(?im)^\s*total:.*?(\d+\.\d+)\s*\|\s*(\d+\.\d+)')
        if ($iopsMatches.Count -gt 0) {
            $last = $iopsMatches[$iopsMatches.Count-1]
            $mbps = [double]$last.Groups[1].Value
            $iops = [double]$last.Groups[2].Value
        }

        $latMatch = [regex]::Match($output, '(?im)^\s*avg.*?(\d+\.\d+)\s*$')
        if ($latMatch.Success) { $lat = [double]$latMatch.Groups[1].Value }

        $diskResults += [pscustomobject]@{
            Profile = $p.Name
            IOPS = $iops
            MBps = $mbps
            AvgLatencyMs = $lat
            RawOutput = $output
        }
    }

    Remove-Item $testFile -Force -ErrorAction SilentlyContinue
    $script:Results.Disk = $diskResults
    Add-Log "Disk benchmark complete."
}

function Invoke-NetworkTest {
    param([string]$IperfPath, [string]$Server)

    if (-not (Test-Path $IperfPath) -or [string]::IsNullOrWhiteSpace($Server)) {
        Add-Log "iperf3 path or server missing. Skipping network test."
        $script:Results.Network = [ordered]@{ Status="SKIPPED"; Reason="iperf3 path or server not configured" }
        return
    }

    Add-Log "Starting iperf3 test against $Server."
    $out = & $IperfPath -c $Server -t 15 -J 2>&1 | Out-String
    try {
        $j = $out | ConvertFrom-Json
        $bps = [double]$j.end.sum_received.bits_per_second
        $script:Results.Network = [ordered]@{
            Server = $Server
            Gbps = [math]::Round($bps / 1e9, 3)
            Retransmits = $j.end.sum_sent.retransmits
            Status = "PASS"
        }
        Add-Log ("Network throughput: {0:N3} Gbps" -f ($bps/1e9))
    } catch {
        $script:Results.Network = [ordered]@{ Status="ERROR"; RawOutput=$out }
        Add-Log "Unable to parse iperf3 result."
    }
}

function Export-Reports {
    $reportDir = Join-Path ([Environment]::GetFolderPath("Desktop")) "PVE-VM-Performance-Reports"
    New-Item -ItemType Directory -Path $reportDir -Force | Out-Null
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $htmlPath = Join-Path $reportDir "VM-Performance-$stamp.html"
    $csvPath = Join-Path $reportDir "VM-Performance-$stamp.csv"

    $inventory = $script:Results.Inventory

    $rows = New-Object System.Collections.Generic.List[object]
    if ($script:Results.CPU) {
        $rows.Add([pscustomobject]@{Category="CPU"; Metric="Average %"; Value=$script:Results.CPU.AveragePercent})
        $rows.Add([pscustomobject]@{Category="CPU"; Metric="Maximum %"; Value=$script:Results.CPU.MaximumPercent})
    }
    if ($script:Results.Memory) {
        $rows.Add([pscustomobject]@{Category="Memory"; Metric="Peak Used %"; Value=$script:Results.Memory.PeakUsedPercent})
        $rows.Add([pscustomobject]@{Category="Memory"; Metric="Stress Allocated GB"; Value=$script:Results.Memory.AllocatedStressGB})
    }
    if ($script:Results.Disk -is [System.Array]) {
        foreach ($d in $script:Results.Disk) {
            $rows.Add([pscustomobject]@{Category="Disk"; Metric="$($d.Profile) IOPS"; Value=$d.IOPS})
            $rows.Add([pscustomobject]@{Category="Disk"; Metric="$($d.Profile) MB/s"; Value=$d.MBps})
        }
    }
    if ($script:Results.Network -and $script:Results.Network.Gbps) {
        $rows.Add([pscustomobject]@{Category="Network"; Metric="Throughput Gbps"; Value=$script:Results.Network.Gbps})
    }
    $rows | Export-Csv -NoTypeInformation -Path $csvPath

    $diskHtml = ""
    if ($script:Results.Disk -is [System.Array]) {
        $diskHtml = ($script:Results.Disk | Select-Object Profile,IOPS,MBps,AvgLatencyMs | ConvertTo-Html -Fragment)
    } else {
        $diskHtml = "<p>Disk test skipped or unavailable.</p>"
    }

    $netText = if ($script:Results.Network.Gbps) { "$($script:Results.Network.Gbps) Gbps" } else { "Skipped/Unavailable" }

    $html = @"
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Windows VM Performance Report</title>
<style>
body { font-family: Segoe UI, Arial; margin:40px; background:#f4f6f8; color:#1f2937; }
h1 { margin-bottom:4px; }
.card { background:white; border-radius:10px; padding:20px; margin:15px 0; box-shadow:0 2px 8px rgba(0,0,0,.08); }
table { border-collapse:collapse; width:100%; }
th,td { padding:9px; border-bottom:1px solid #ddd; text-align:left; }
.good { font-weight:600; }
</style>
</head>
<body>
<h1>Windows 11 VM Performance Report</h1>
<p>Generated: $(Get-Date)</p>
<div class="card">
<h2>VM Inventory</h2>
<table>
<tr><td>Hostname</td><td>$($inventory.Hostname)</td></tr>
<tr><td>OS</td><td>$($inventory.OS)</td></tr>
<tr><td>CPU</td><td>$($inventory.CPU)</td></tr>
<tr><td>Logical CPUs</td><td>$($inventory.LogicalCPUs)</td></tr>
<tr><td>RAM</td><td>$($inventory.MemoryGB) GB</td></tr>
<tr><td>System Drive</td><td>$($inventory.SystemDriveGB) GB</td></tr>
</table>
</div>
<div class="card">
<h2>CPU</h2>
<p>Average utilization: <b>$($script:Results.CPU.AveragePercent)%</b></p>
<p>Maximum utilization: <b>$($script:Results.CPU.MaximumPercent)%</b></p>
</div>
<div class="card">
<h2>Memory</h2>
<p>Peak utilization: <b>$($script:Results.Memory.PeakUsedPercent)%</b></p>
<p>Stress allocation: <b>$($script:Results.Memory.AllocatedStressGB) GB</b></p>
</div>
<div class="card">
<h2>DiskSpd</h2>
$diskHtml
</div>
<div class="card">
<h2>Network</h2>
<p>Throughput: <b>$netText</b></p>
</div>
<div class="card">
<h2>Notes for Proxmox Testing</h2>
<p>Use the same VM specification and test profile when comparing CPU type, VirtIO driver versions, SCSI controller, cache mode, Ceph/RBD configuration, NUMA, ballooning, and migration performance.</p>
</div>
</body>
</html>
"@

    Set-Content -Path $htmlPath -Value $html -Encoding UTF8
    Add-Log "Reports exported to $reportDir"
    Start-Process $htmlPath
}

# ---------------- GUI ----------------

[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        Title="Proxmox VM Performance Test" Height="720" Width="920"
        WindowStartupLocation="CenterScreen" ResizeMode="CanResize">
<Grid Margin="16">
  <Grid.RowDefinitions>
    <RowDefinition Height="Auto"/>
    <RowDefinition Height="Auto"/>
    <RowDefinition Height="Auto"/>
    <RowDefinition Height="Auto"/>
    <RowDefinition Height="*"/>
    <RowDefinition Height="Auto"/>
  </Grid.RowDefinitions>

  <StackPanel Grid.Row="0">
    <TextBlock Text="PROXMOX VM PERFORMANCE TEST" FontSize="24" FontWeight="Bold"/>
    <TextBlock Text="Windows 11 VM CPU, Memory, Disk and Network Validation" Margin="0,4,0,12"/>
  </StackPanel>

  <GroupBox Grid.Row="1" Header="Test Selection" Margin="0,0,0,10">
    <StackPanel Margin="10">
      <WrapPanel>
        <CheckBox x:Name="chkCPU" Content="CPU Stress" IsChecked="True" Margin="0,0,20,0"/>
        <CheckBox x:Name="chkMemory" Content="Memory Stress" IsChecked="True" Margin="0,0,20,0"/>
        <CheckBox x:Name="chkDisk" Content="DiskSpd" IsChecked="True" Margin="0,0,20,0"/>
        <CheckBox x:Name="chkNetwork" Content="iperf3 Network" Margin="0,0,20,0"/>
      </WrapPanel>
      <WrapPanel Margin="0,10,0,0">
        <TextBlock Text="CPU/Memory Duration:" VerticalAlignment="Center"/>
        <ComboBox x:Name="cmbDuration" Width="120" Margin="8,0,20,0" SelectedIndex="1">
          <ComboBoxItem Content="1 minute"/>
          <ComboBoxItem Content="5 minutes"/>
          <ComboBoxItem Content="10 minutes"/>
          <ComboBoxItem Content="15 minutes"/>
          <ComboBoxItem Content="30 minutes"/>
        </ComboBox>
      </WrapPanel>
    </StackPanel>
  </GroupBox>

  <GroupBox Grid.Row="2" Header="External Tools" Margin="0,0,0,10">
    <Grid Margin="10">
      <Grid.ColumnDefinitions><ColumnDefinition Width="150"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
      <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
      <TextBlock Grid.Row="0" Grid.Column="0" Text="DiskSpd.exe path:"/>
      <TextBox Grid.Row="0" Grid.Column="1" x:Name="txtDiskSpd" Text="C:\Tools\DiskSpd\diskspd.exe"/>
      <TextBlock Grid.Row="1" Grid.Column="0" Text="iperf3.exe path:" Margin="0,6,0,0"/>
      <TextBox Grid.Row="1" Grid.Column="1" x:Name="txtIperf" Text="C:\Tools\iperf3\iperf3.exe" Margin="0,6,0,0"/>
      <TextBlock Grid.Row="2" Grid.Column="0" Text="iperf3 server:" Margin="0,6,0,0"/>
      <TextBox Grid.Row="2" Grid.Column="1" x:Name="txtIperfServer" Margin="0,6,0,0"/>
    </Grid>
  </GroupBox>

  <GroupBox Grid.Row="3" Header="Live Performance" Margin="0,0,0,10">
    <StackPanel Margin="10">
      <WrapPanel>
        <TextBlock x:Name="lblCPU" Text="CPU: --" Width="170" FontWeight="SemiBold"/>
        <TextBlock x:Name="lblMemory" Text="Memory: --" Width="170" FontWeight="SemiBold"/>
        <TextBlock x:Name="lblStatus" Text="Ready" FontWeight="SemiBold"/>
      </WrapPanel>
      <ProgressBar x:Name="progress" Height="18" Minimum="0" Maximum="100" Margin="0,8,0,0"/>
    </StackPanel>
  </GroupBox>

  <GroupBox Grid.Row="4" Header="Test Log">
    <TextBox x:Name="txtLog" Margin="8" FontFamily="Consolas" IsReadOnly="True"
             VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto"
             AcceptsReturn="True"/>
  </GroupBox>

  <WrapPanel Grid.Row="5" HorizontalAlignment="Right" Margin="0,12,0,0">
    <Button x:Name="btnStart" Content="START TEST" Width="120" Height="34" Margin="0,0,8,0"/>
    <Button x:Name="btnStop" Content="STOP" Width="90" Height="34" Margin="0,0,8,0"/>
    <Button x:Name="btnExport" Content="EXPORT REPORT" Width="130" Height="34"/>
  </WrapPanel>
</Grid>
</Window>
'@

$reader = New-Object System.Xml.XmlNodeReader $xaml
$window = [Windows.Markup.XamlReader]::Load($reader)

foreach ($name in @("chkCPU","chkMemory","chkDisk","chkNetwork","cmbDuration","txtDiskSpd","txtIperf","txtIperfServer",
                     "lblCPU","lblMemory","lblStatus","progress","txtLog","btnStart","btnStop","btnExport")) {
    Set-Variable -Name $name -Value $window.FindName($name) -Scope Script
}

$script:Results.Inventory = Get-SystemInventory

if (-not (Test-IsAdministrator)) {
    $txtLog.AppendText("WARNING: Run PowerShell as Administrator for best results.`r`n")
}

$btnStart.Add_Click({
    $script:StopRequested = $false
    $btnStart.IsEnabled = $false
    try {
        $script:Results = [ordered]@{ Inventory = Get-SystemInventory }
        $duration = Get-DurationSeconds

        if ($chkCPU.IsChecked) {
            Update-Status "CPU stress test..." 10
            Invoke-CPUStress -Seconds $duration
        }
        if ($chkMemory.IsChecked -and -not $script:StopRequested) {
            Update-Status "Memory stress test..." 35
            Invoke-MemoryStress -Seconds $duration
        }
        if ($chkDisk.IsChecked -and -not $script:StopRequested) {
            Update-Status "Disk benchmark..." 60
            Invoke-DiskSpdTest -DiskSpdPath $txtDiskSpd.Text
        }
        if ($chkNetwork.IsChecked -and -not $script:StopRequested) {
            Update-Status "Network benchmark..." 85
            Invoke-NetworkTest -IperfPath $txtIperf.Text -Server $txtIperfServer.Text
        }

        if ($script:StopRequested) {
            Update-Status "Stopped by user" 0
            Add-Log "Testing stopped by user."
        } else {
            Update-Status "Testing complete" 100
            Add-Log "All selected tests completed."
        }
    } catch {
        Add-Log "ERROR: $($_.Exception.Message)"
        Update-Status "Error" 0
    } finally {
        $btnStart.IsEnabled = $true
    }
})

$btnStop.Add_Click({
    $script:StopRequested = $true
    Add-Log "Stop requested."
})

$btnExport.Add_Click({
    try { Export-Reports } catch { Add-Log "Export error: $($_.Exception.Message)" }
})

$window.ShowDialog() | Out-Null
