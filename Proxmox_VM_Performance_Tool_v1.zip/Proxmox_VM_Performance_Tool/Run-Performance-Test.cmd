@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Proxmox-VM-Performance-Test.ps1"
